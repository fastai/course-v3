from starlette.applications import Starlette
from starlette.responses import HTMLResponse, JSONResponse
from starlette.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
import uvicorn
from fastai import *
from fastai.vision import *

from io import BytesIO

app = Starlette()
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_headers=['X-Requested-With', 'Content-Type'])
app.mount('/static', StaticFiles(directory='app/static'))

path = os.path.dirname(os.path.abspath(__file__))
classes = ['black', 'grizzly', 'teddys']
data_bunch = ImageDataBunch.single_from_classes(path, classes,
                                                tfms=get_transforms(), size=224).normalize(imagenet_stats)
learn = create_cnn(data_bunch, models.resnet34)
learn.load('stage-2')

@app.route('/')
def index(request):
    html = os.path.join(path, 'view', 'index.html')
    return HTMLResponse(open(html, 'r', encoding='utf-8').read())

@app.route('/analyze', methods=['POST'])
async def analyze(request):
    data = await request.form()
    img_bytes = await (data['file'].read())
    img = open_image(BytesIO(img_bytes))
    pred_class, _, _ = learn.predict(img)
    return JSONResponse({'result': pred_class})

if __name__ == '__main__':
    if 'serve' in sys.argv:
        uvicorn.run(app, host='0.0.0.0', port=5042)