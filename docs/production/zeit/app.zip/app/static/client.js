const HOSTURL = 'https://deploy-ml-demo.now.sh';

function showFilePicker(inputId) {
    var input = document.getElementById('file-input');
    input.click();
}

function showFilePicked() {
    var files = document.getElementById('file-input').files;
    if (files.length == 1) {
        document.getElementById('upload-label').innerHTML = files[0].name;
    }
}

function analyze() {
    var uploadFiles = document.getElementById('file-input').files;
    if (uploadFiles.length != 1) {
        alert('Please select 1 file to analyze!');
    }

    var fileData = new FormData();
    fileData.append('file', uploadFiles[0]);

    document.getElementById('analyze-button').innerHTML = 'Analyzing...';
    var xhr = new XMLHttpRequest();
    xhr.open('POST', `${HOSTURL}/analyze`, true);
    xhr.onerror = function() {alert (xhr.responseText);}
    xhr.onload = function(e) {
        if (this.readyState === 4) {
            var response = JSON.parse(e.target.responseText);
            document.getElementById('result-label').innerHTML = `Result = ${response['result']}`;
        }
        document.getElementById('analyze-button').innerHTML = 'Analyze';
    }
    xhr.send(fileData);
}